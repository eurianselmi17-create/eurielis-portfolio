import { useState } from "react"

export default function Portfolio() {
  const [active, setActive] = useState("home")

  return (
    <div className="min-h-screen bg-ink text-ivory">

      {/* NAV */}
      <div className="fixed top-6 left-6 flex gap-4 text-sm opacity-70">
        {["home","about","work","skills","contact"].map(i => (
          <button key={i} onClick={() => setActive(i)} className="hover:opacity-100">
            {i.toUpperCase()}
          </button>
        ))}
      </div>

      {/* HERO */}
      <section className="h-screen flex flex-col justify-center items-center text-center">
        <h1 className="text-6xl md:text-8xl tracking-tight">
          Eurielis García
        </h1>
        <p className="mt-4 opacity-70">
          Community Manager • Digital Strategist • Brand Growth
        </p>
      </section>

      {/* ABOUT */}
      <section className="min-h-screen px-10 md:px-32 py-32">
        <h2 className="text-3xl mb-6">About</h2>
        <p className="max-w-2xl opacity-80 leading-relaxed">
          Profesional en Publicidad y Mercadeo enfocada en crecimiento de marcas,
          estrategias digitales y ventas consultivas con enfoque en performance y posicionamiento.
        </p>
      </section>

      {/* EXPERIENCE */}
      <section className="min-h-screen px-10 md:px-32 py-32 space-y-16">
        <h2 className="text-3xl">Experience</h2>

        <div>
          <h3 className="text-xl">Perfumería Celestina</h3>
          <p className="opacity-70">Estrategia digital, WhatsApp Business, crecimiento orgánico.</p>
        </div>

        <div>
          <h3 className="text-xl">Ferre-Metal del Pueblo</h3>
          <p className="opacity-70">Diseño visual, catálogos, marketing local.</p>
        </div>

        <div>
          <h3 className="text-xl">Mansión Imperial</h3>
          <p className="opacity-70">Activaciones de marca y campañas gastronómicas.</p>
        </div>
      </section>

      {/* SKILLS */}
      <section className="min-h-screen px-10 md:px-32 py-32">
        <h2 className="text-3xl mb-10">Skills</h2>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 opacity-80">
          {["Community","Copywriting","Meta Ads","Canva","Sales","Branding"].map(s => (
            <div key={s} className="p-4 border border-white/10 rounded-xl">
              {s}
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section className="min-h-screen flex flex-col justify-center items-center text-center">
        <h2 className="text-3xl">Contact</h2>
        <p className="opacity-70 mt-4">
          WhatsApp • Email • Location
        </p>
      </section>

    </div>
  )
}
