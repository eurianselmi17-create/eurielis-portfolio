/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0b0b0f",
        ivory: "#f5f1e8"
      }
    }
  },
  plugins: []
}
